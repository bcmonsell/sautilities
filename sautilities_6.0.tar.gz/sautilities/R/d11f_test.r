#' D11 F-test for residual seasonality
#'
#' Generates X-11's F-test for residual seasonality in the seasonally adjusted data.
#' For more information on X-11 diagnostics, see 
#' \insertCite{LadirayQuenneville2001;textual}{sautilities} and 
#' \insertCite{LothianMorry78;textual}{sautilities}.
#'
#' Version 5.1, 2026-03-05
#'
#' @param seas_obj A \code{seas} object for a single series generated from the 
#'        \code{seasonal} package \insertCite{seasonal2018}{sautilities}. 
#'        This is a required entry.
#' @param p_level P-level used to test the D11 f-test for residual seasonality
#'        Default is \code{0.01}.
#' @param return_this Character string; what the function returns - 
#'        \code{'test'} returns test results, \code{'why'} returns why the test failed or 
#'        received a warning, or \code{'both'}. Default is \code{'test'}.
#' @return A text string denoting if series passes or has a warning for residual seasonality. 
#'         If D11f statistic not found, return \code{'none'}.
#'
#' @author Brian C. Monsell, \email{monsell.brian@@bls.gov} or \email{bcmonsell@@gmail.com}
#'
#' @references
#'  \insertAllCited{}
#'
#' @examples
#' ukgas_seas <- 
#'    seasonal::seas(UKgas, 
#'                   series.period = 4, 
#'                   transform.function = "log", 
#'                   arima.model = "(0 1 1)(0 1 1)",
#'                   forecast.maxlead=20,
#'                   check.print = c( "pacf", "pacfplot" ), 
#'                   x11="")
#' ukgas_d11f_test <- 
#'    d11f_test(ukgas_seas, 
#'              p_level = 0.05, 
#'              return_this = 'both')
#' @importFrom Rdpack reprompt
#' @export
d11f_test <- 
    function(seas_obj = NULL, 
	         p_level = 0.01, 
			 return_this = "test") {
    # Author: Brian C. Monsell (OEUS) Version 5.1, 2026-03-05
    
    # check if a value is specified for \code{seas_obj}
    if (is.null(seas_obj)) {
        stop("must specify a seas object")
   } else {
    # check if a seas object is specified for \code{seas_obj}
        if (!inherits(seas_obj, "seas")) {
           stop("First argument must be a seas object")
        }
    }
    
    # set \code{is_test}, \code{is_why}, \code{is_both}
    is_test <- FALSE
    is_why <- FALSE
    is_both <- FALSE
    return_this <- tolower(return_this)
    if (return_this == "test") {
        is_test <- TRUE
    }
    if (return_this == "why") {
        is_why <- TRUE
    }
    if (return_this == "both") {
        is_test <- TRUE
        is_why <- TRUE
        is_both <- TRUE
    }
    
    # check for improper entry for \code{return_this}
    if (!is_test & !is_why) {
        print(paste("Improper entry for return_this : ", return_this, sep = ""))
        return(NULL)
    }
    
    # Check to see if the D11 F-test for residual seasonality is one of the diagnostics
    # in the UDG file
    this_udg <- seasonal::udg(seas_obj)
    this_index <- get_udg_index(this_udg, "d11.f")
    if (length(this_index) > 1) {
        if (is_both) {
            return(c("error","    "))
        } else {
            return("error")
        }
    }
    if (this_index == 0) {
        if (is_both) {
            return(c("none","    "))
        } else {
            return("none")
        }
    }
    
    # Extract p-value for D11 F-statistic
    this_p_value <- this_udg[[this_index]][2]/100
    
    # If p-value is less than limit set, set this_test to \code{'warn'}
    if (this_p_value < p_level) {
        this_test <- "warn"
        if (is_why) {
            this_why <- 
                d11f_test_why(this_udg, p_level = p_level, return_both = is_both)
        }
    } else {
        # Extract p-value for D11 F-statistic for last 3 years of data
        this_3y_p_level <- this_udg[["d11.3y.f"]][2]/100
        
        # If p-value is less than limit set, set this_test to \code{'warn'}.
        if (this_3y_p_level < p_level) {
            this_test <- "warn"
            if (is_why) {
                this_why <- 
                    d11f_test_why(this_udg, p_level = p_level, return_both = is_both)
            }
            # else, set this_test to \code{'pass'}
        } else {
            this_test <- "pass"
            this_why <- "    "
            if (return_this == "why") {
                this_why <- "pass"
            }
        }
    }
    # return \code{this_test} or \code{this_why} based on value of \code{return_this}
    
    if (return_this == "both") {
        return(cbind(this_test, this_why))
    }
    if (is_test) {
        return(this_test)
    }
    return(this_why)
}
