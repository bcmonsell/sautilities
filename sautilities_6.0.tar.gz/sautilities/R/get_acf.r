#' Get ACF values, diagnostics
#'
#' Extract values from the sample ACF of the regARIMA model residuals, 
#' along with Ljung-Box Q values \insertCite{LjungBox78}{sautilities}.
#'
#' Version 3.1, 2026-03-06
#'
#' @param seas_obj A \code{seas} object for a single series generated from the 
#'        \code{seasonal} package \insertCite{seasonal2018}{sautilities}. 
#'        This is a required entry.
#' @param lags An array of integer lags to extract from the ACF output. 
#'        If not specified, all lags will be returned.
#' @param as_data_frame Logical scalar. 
#'        If \code{TRUE}, the values are returned as a data frame.
#'        If \code{FALSE}, the result is returned as a matrix object. 
#'        Default is \code{TRUE}.
#' @param add_rownames Logical scalar. 
#'        If \code{TRUE}, row names are constructed from the lags specified by the user.
#'        If \code{FALSE}, no rownames will be added. Default is \code{TRUE}.
#' @return A data frame (or matrix) with 5 columns:  
#'         \code{"Sample_ACF"} (sample ACF Value),
#'         \code{"SE_of_ACF"} (ACF standard error), 
#'         \code{"Ljung.Box_Q"} (Ljung-Box Q statistic), 
#'         \code{"df_of_Q"} (degrees of freedom for Ljung=Box Q), and 
#'         \code{"P.value"} (p-value for Ljung Box Q).
#'
#' @author Brian C. Monsell, \email{monsell.brian@@bls.gov} or \email{bcmonsell@@gmail.com}
#'
#' @references
#'  \insertAllCited{}
#'
#' @examples
#' air_seas <- 
#'    seasonal::seas(AirPassengers,
#'       arima.model="(0 1 1)(0 1 1)",
#'       check.save = "acf",
#'       check.maxlag = 36,
#'       forecast.maxlead = 36, slidingspans = "",
#'       transform.function = "log")
#' air_acf_df <- 
#'    get_acf(air_seas, lags = c(1,2,3,12,13,24))
#' @importFrom Rdpack reprompt
#' @export
get_acf <- 
   function(seas_obj = NULL, 
            lags = NULL, 
            as_data_frame = TRUE, 
            add_rownames = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 3.1, 2026-03-06

    # check if a value is specified for \code{seas_obj}
    if (is.null(seas_obj)) {
        stop("must specify a seas object")
    } else {
    # check if a seas object is specified for \code{seas_obj}
        if (!inherits(seas_obj, "seas")) {
           stop("First argument must be a seas object")
        }
    } 
    
    # extract acf from seasonal object
    this_acf <- seasonal::series(seas_obj, "acf")
	
    # if \code{lags = NULL}, keep all lags
	if (is.null(lags)) {
	
	# if \code{as_data_frame = TRUE}, convert matrix to a data frame
	    if (as_data_frame) {
		    this_acf <- data.frame(this_acf)
		} else {
		    if (is.null(nrow(this_acf))) {
			    this_acf <- t(as.matrix(this_acf))
			}
		}

    # generate row names and add them to \code{this_acf}
		if (add_rownames) {
		    n_lags   <- nrow(this_acf)
			row_label <- paste("lag", seq(1, lags))
			rownames(this_acf) <- row_label
		}
	} else {

    # extract lags from acf matrix
	    this_acf <- this_acf[lags,]

	# if \code{as_data_frame = TRUE}, convert matrix to a data frame
		if (as_data_frame) {
		    this_acf <- data.frame(this_acf)
		} else {
		    if (is.null(nrow(this_acf))) {
			    this_acf <- t(as.matrix(this_acf))
			}
		}

    # generate row names and add them to \code{this_acf}
		if (add_rownames) {
	        row_label <- paste("lag", lags)
		    rownames(this_acf) <- row_label
		}
	}
	
    # return \code{this_acf}
	return(this_acf)

}

