#' Displays various X-13 diagnostics
#'
#' Displays various X-13ARIMA-SEATS diagnostics for a single series \insertCite{Census2025}{sautilities}.
#' Seasonality diagnostics are described in \insertCite{Bell2022;textual}{sautilities}.
#' Adapted from a script developed by Osbert Pang (US Census Bureau, osbert.c.pang@@census.gov)
#'
#' Version 4.2, 2026-03-05
#'
#' @param seas_obj A \code{seas} object for a single series generated from the 
#'        \code{seasonal} package \insertCite{seasonal2018}{sautilities}. 
#'        This is a required entry.
#' @param print_summary Logical object; if \code{TRUE}, print the result of 
#'        \code{summary(seas_obj}); 
#'        if \code{FALSE}, a model summary will be printed out.
#'        Default is \code{TRUE}.
#' @param test_full Logical scalar indicating whether to apply the QS test 
#'        to the full series span.
#'        Default is \code{TRUE}.
#' @param test_span Logical scalar indicating whether to test the QS test 
#'        to the final 8-year span used by the spectrum diagnostic.
#'        Default is \code{TRUE}.
#' @param acf_num_sig Numeric object; limit for number of lags with 
#'        significant ACF values.
#'        Default is \code{8}.
#' @param acf_lags_fail Numeric vector; lags of the ACF to test.
#'        Default is \code{c(1, 2, 3, 4, 12, 24)}.
#' @param acf_lags_warn Numeric vector; lags of the ACF to test for warnings,
#'        Default is \code{c(12, 24)}.
#' @param model_t_value t-statistic limit for regressors.
#'        Default is \code{3.0}.
#' @param model_p_value p-value limit for regressors.
#'        Default is \code{0.05}.
#' @param otl_auto_limit limit for number of automatically identified outliers.
#'        Default is \code{5}.
#' @param otl_all_limit limit for number of outlier regressors.
#'        Default is \code{5}.
#' @param d11f_p_level p-level used to test the d11 f-test for residual seasonality.
#'        Default is \code{0.01}.
#' @param qs_p_limit_pass Numeric scalar; P-value limit for QS statistic for passing.
#'        Default is \code{0.01}.
#' @param qs_p_limit_warn Numeric scalar; P-value limit for QS statistic for warning.
#'        Default is \code{0.05}.
#' @param qs_p_limit_fail Numeric scalar; P-value limit for QS statistic for failing.
#'        Default is \code{0.01}.
#' @param qs_robust_sa Logical scalar indicating if original series adjusted for 
#'        extremes is included in testing.
#'        Default is \code{TRUE}.
#' @param sf_limit Numeric object; limit for the percentage of seasonal spans flagged.
#'        Default is \code{25}.
#' @param change_limit Numeric object; limit for the percentage of month-to-month 
#'        changes flagged.
#'        Default is \code{40}.
#' @param mq_fail_limit Numeric scalar; value above which the M or Q statistic fails.
#'        Default is \code{1.2}.
#' @param mq_warn_limit Numeric scalar; value above which the M or Q statistic gives 
#'        a warning message if it is less than \code{this_fail_limit}, 
#'        Default is \code{0.8}.
#' @param return_list Logical scalar; indicates if the function will return a summary of 
#'        diagnostics. Default is \code{TRUE}.
#' @return Displays assorted seasonal adjustment and modeling diagnostics.
#'
#' @author Brian C. Monsell, \email{monsell.brian@@bls.gov} or \email{bcmonsell@@gmail.com}
#'
#' @references
#'  \insertAllCited{}
#'
#' @examples
#' ukgas_seas <- 
#'      seasonal::seas(UKgas, 
#'           series.period = 4, 
#'           arima.model = "(0 1 1)(0 1 1)", 
#'           x11="", 
#'           transform.function = "log", 
#'           forecast.maxlead=20,
#'           check.print = c( "pacf", "pacfplot" ))
#' ukgas_check_stats <- 
#'    check_stats(ukgas_seas, 
#'                acf_num_sig = 5, 
#'                acf_lags_fail = c(1, 2, 3, 4, 8), 
#'                acf_lags_warn = c(4, 8), 
#'                otl_auto_limit = 4, 
#'                otl_all_limit = 6, 
#'                return_list = TRUE)
#' @importFrom Rdpack reprompt
#' @export
check_stats <- 
   function(seas_obj = NULL, 
            print_summary = TRUE, 
            test_full = TRUE, 
            test_span = TRUE, 
            acf_num_sig = 8, 
            acf_lags_fail = c(1, 2, 3, 4, 12, 24), 
            acf_lags_warn = c(12, 24), 
            model_t_value = 3, 
            model_p_value = 0.05, 
            otl_auto_limit = 5, 
            otl_all_limit = 5, 
            d11f_p_level = 0.01, 
            qs_p_limit_pass = 0.01, 
            qs_p_limit_warn = 0.05, 
            qs_p_limit_fail = 0.01, 
            qs_robust_sa = TRUE, 
            sf_limit = 25, 
            change_limit = 40, 
            mq_fail_limit = 1.2, 
            mq_warn_limit = 0.8, 
            return_list = FALSE) {
    # Author: Brian C. Monsell (OEUS) Version 4.2, 2026-03-05
    
   
    # check if a value is specified for \code{seas_obj}
    if (is.null(seas_obj)) {
        stop("must specify a seas object")
    } else {
    # check if a seas object is specified for \code{seas_obj}
        if (!inherits(seas_obj, "seas")) {
            stop("First argument must be a seas object")
        }
    }
    
    # generate UDG output for \code{seas_obj}
    udg_all <- seasonal::udg(seas_obj)
    
    # print the summary of the seas object
    if (print_summary) {
        sum_seas_obj <- summary(seas_obj)
        print(sum_seas_obj)
    } else {
        # else, print summary of the regARIMA model
        if (udg_all[["mdg"]] == "yes") {
            num_reg <- udg_all[["nreg"]]
            if (num_reg > 0) {
                cat("  Regressors    : ", get_reg_string(seas_obj), fill = TRUE)
            }
            cat("  ARIMA Model   : ", udg_all[["arimamdl"]], fill = TRUE)
        }
    }
    cat(" --- ", fill = TRUE)
    
    # Display QS seasonal test
    this_qs_seasonal <- 
	   qs_seasonal_test(seas_obj, 
	      test_full = test_full, 
	      test_span = test_span, 
	      p_limit_pass = qs_p_limit_pass, 
	      p_limit_warn = qs_p_limit_warn, 
	      robust_sa = qs_robust_sa, 
	      return_this = "both")
    cat("  QS.seasonal   : ", paste(this_qs_seasonal, collapse = " "), fill = TRUE)
    
    # Display regARIMA model test
    this_model_test <- 
	   model_test(seas_obj, 
	      t_value = model_t_value, 
	      p_value = model_p_value, 
	      otl_auto_limit = otl_auto_limit, 
	      otl_all_limit = otl_all_limit, 
	      return_this = "both")
    cat("  model.test    : ", paste(this_model_test, collapse = " "), fill = TRUE)
    
    # Display results of residual ACF test
    this_acf_test <- 
	   acf_test(seas_obj, 
	      num_sig = acf_num_sig, 
		  acf_lags_fail = acf_lags_fail, 
		  acf_lags_warn = acf_lags_warn,
		  return_this = "both")
    cat("  acf.test      : ", paste(this_acf_test, collapse = " "), fill = TRUE)
    
    # Display results of regARIMA residuals QS test
    this_qs_rsd_test <- 
	   qs_rsd_test(seas_obj, 
	      test_full = test_full, 
	      test_span = test_span, 
	      p_limit_fail = qs_p_limit_fail, 
	      p_limit_warn = qs_p_limit_warn, 
	      return_this = "both")
    cat("  QS.residual   : ", paste(this_qs_rsd_test, collapse = " "), fill = TRUE)
    
    # Display results of SA QS test
    this_qs_test <- 
	   qs_test(seas_obj, 
	      test_full = test_full, 
	      test_span = test_span, 
	      p_limit_fail = qs_p_limit_fail, 
	      p_limit_warn = qs_p_limit_warn, 
	      return_this = "both")
    cat("  QS            : ", paste(this_qs_test, collapse = " "), fill = TRUE)
    
    # Display results of D11 F-test
    this_d11f_test <- 
	   d11f_test(seas_obj, 
	      p_level = d11f_p_level, 
	      return_this = "both")
    cat("  D11.Ftest     : ", paste(this_d11f_test, collapse = " "), fill = TRUE)
    
    # Display results of Sliding Spans test
    this_sspan_test <- 
	   sspan_test(seas_obj, 
	      sf_limit = sf_limit, 
	      change_limit = change_limit, 
	      return_this = "both")
    cat("  Sliding spans : ", paste(this_sspan_test, collapse = " "), fill = TRUE)
    
    # Display M7, Q2 - both should be between 0 and 1
    m7_test <- 
	   mq_test(seas_obj, 
	      this_fail_limit = mq_fail_limit, 
	      this_warn_limit = mq_warn_limit, 
          return_this = "both")
    q2_test <- 
		mq_test(seas_obj, 
		   this_label = "q2", 
		   this_fail_limit = mq_fail_limit, 
		   this_warn_limit = mq_warn_limit, 
           return_this = "both")
    cat("  M7            : ", paste(m7_test, collapse = " "), fill = TRUE)
    cat("  Q2            : ", paste(q2_test, collapse = " "), fill = TRUE)
    
    if (return_list) {
        this_list <- list()
        if (udg_all[["mdg"]] == "yes") {
            this_list$regressors <- get_reg_string(seas_obj)
            this_list$arima <- udg_all[["arimamdl"]]
        }
        this_list$model <- paste(this_model_test, collapse = " ")
        this_list$acf <- paste(this_acf_test, collapse = " ")
        this_list$qs_seasonal <- paste(this_qs_seasonal, collapse = " ")
        this_list$qs_rsd <- paste(this_qs_rsd_test, collapse = " ")
        this_list$qs <- paste(this_qs_test, collapse = " ")
        this_list$d11f <- paste(this_d11f_test, collapse = " ")
        this_list$sspan <- paste(this_sspan_test, collapse = " ")
        this_list$m7 <- paste(m7_test, collapse = " ")
        this_list$q2 <- paste(q2_test, collapse = " ")
        return(this_list)
    }
    
}
