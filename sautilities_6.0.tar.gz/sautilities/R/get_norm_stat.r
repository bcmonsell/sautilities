#' Extract normality statistics from X-13
#' 
#' Extract normality statistics from the \code{seas} object of a single series.
#' 
#' Version 4.1, 2026-03-05
#'
#' @param seas_obj A \code{seas} object for a single series generated from the 
#'        \code{seasonal} package \insertCite{seasonal2018}{sautilities}.
#'        This is a required entry.
#' @param this_norm character string; type of normality statistic being extracted. 
#'        Permissable values are \code{'a'}, \code{'kurtosis'}, \code{'skewness'}.
#'        This is a required entry.
#' @return Double precision number for normality statistic described in this_key. 
#'         If incorrect \code{this_key} used, function returns a \code{NULL} value. 
#'         If normality statistic not generated in this run, function returns a \code{NULL} value.
#'         Descriptions of these diagnostics can be found in Section 7.3 of 
#'         \insertCite{Census2025;textual}{sautilities}.
#'
#' @author Brian C. Monsell, \email{monsell.brian@@bls.gov} or \email{bcmonsell@@gmail.com}
#'
#' @references
#'  \insertAllCited{}
#'
#' @examples 
#' air_seas <- 
#'    seasonal::seas(AirPassengers, 
#'                   transform.function = "log", 
#'                   forecast.maxlead=36, 
#'                   check.print = c( "pacf", "pacfplot" ), 
#'                   x11 = "", 
#'                   slidingspans = "")
#' air_norm_stat <- 
#'    get_norm_stat(air_seas, this_norm = 'kurtosis')
#' @importFrom Rdpack reprompt
#' @export
get_norm_stat <- function(seas_obj = NULL, this_norm = NULL) {
    # Author: Brian C. Monsell (OEUS) Version 4.1, 2026-03-05
    
    # check if a value is specified for \code{seas_obj}
    if (is.null(seas_obj)) {
        stop("must specify a seas object")
    } else {
    # check if a seas object is specified for \code{seas_obj}
        if (!inherits(seas_obj, "seas")) {
           stop("First argument must be a seas object")
        }
    }
    
    # check if a value is specified for \code{this_norm}
    if (is.null(this_norm)) {
        stop("must specify a type of normality statistic")
    }
    
    # Check for valid entries of \code{this_norm}
    this_norm <- tolower(this_norm)
    if (this_norm == "a" | this_norm == "kurtosis" | this_norm == "skewness") {
        # extract normality statistics if UDG keyword not found, 
        # print out error message and return \code{NA}
        this_norm_stat <- tryCatch(seasonal::udg(seas_obj, this_norm), error = function(e) {
            print(paste("this_norm not found: ", this_norm, sep = ""))
            return(NA)
        })
        
        # if length of \code{this_norm_stat} is more than 1, 
        # convert first element to double precision
        if (length(this_norm_stat) > 1) {
            return(as.double(this_norm_stat[1]))
        }
        
        # return normality statistic
        return(this_norm_stat)
    }
    
    # if entry not found, print warning and return \code{NULL}
    warning(paste("improper value for this_norm: ", this_norm))
    return(NULL)
}
