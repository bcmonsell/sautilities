#' QS diagnostic test on a number of series.
#'
#' Apply QS Tests to a list of \code{seas} objects.
#' For details on the QS test, see Section 7.17 of 
#' \insertCite{Census2025;textual}{sautilities}, 
#' \insertCite{Maravall2012;textual}{sautilities}, and 
#' \insertCite{Bell2022;textual}{sautilities}.
#' Information on generating adjustments of multiple time series stored in a
#' list object with the \code{seasonal} package can be found in 
#' \insertCite{rprojectAdjustingMultiple;textual}{sautilities}. 
#'
#' Version 4.1, 2026-03-05 
#'
#' @param seas_obj_list List object of \code{seas} objects generated from a call 
#'        of \code{seas} on a list consisting of individual time series.
#         This is a required entry.
#' @param this_stat Character string that specifies which QS statistic is being tested. 
#'        Allowable values are \code{'qsori'}, \code{'qsorievadj'}, \code{'qsrsd'}, 
#'        \code{'qssadj'}, \code{'qssadjevadj'}, \code{'qsirr'}, \code{'qsirrevadj'}, 
#'        \code{'qssori'}, \code{'qssorievadj'}, \code{'qssrsd'}, \code{'qsssadj'}, 
#'        \code{'qsssadjevadj'}, \code{'qssirr'}, \code{'qssirrevadj'}.
#'        Default is \code{"qsori"}.
#' @param less_than Logical scalar which indicates if the test is going to be 
#'        QS less than \code{p_limit} (\code{less_than} = TRUE) or 
#'        QS greater than \code{p_limit} (\code{less_than} = FALSE). 
#'        Default is \code{TRUE}.
#' @param p_limit Numeric scalar; P-value limit for QS statistic. 
#'        Default is \code{0.01}.
#' @return A vector of list element names that have the given QS statistic either 
#'         less than or greater than the given P-value limit. If nothing matches, 
#'         the function will output the string \code{'none'}. 
#'
#' @author Brian C. Monsell, \email{monsell.brian@@bls.gov} or \email{bcmonsell@@gmail.com}
#'
#' @references
#'  \insertAllCited{}
#'
#' @examples
#' emp_seas_list <- 
#'    seasonal::seas(employment_list, 
#'       transform.function = "log",
#'       arima.model = "(0 1 1)(0 1 1)",
#'       regression.aictest = NULL, 
#'       check.print = c( "pacf", "pacfplot" ), 
#'       forecast.maxlead=60, 
#'       x11 = "", 
#'       slidingspans = "")
#' test_seas_update <- 
#'    Filter(function(x) inherits(x, "seas"), emp_seas_list)
#' test_qs_names <- 
#'    qs_series(test_seas_update, 
#'       this_stat = 'qssori', 
#'       less_than = FALSE, 
#'       p_limit = 0.025)
#' @importFrom Rdpack reprompt
#' @export
qs_series <- 
   function(seas_obj_list = NULL, 
      this_stat = "qsori", 
      less_than = TRUE, 
      p_limit = 0.01) {
    # Author: Brian C. Monsell (OEUS) Version 4.1, 2026-03-05 
    
    # check if a value is specified for \code{seas_obj_list}
    if (is.null(seas_obj_list)) {
        stop("must specify a list of seas objects")
    } else {
        if (!is.list(seas_obj_list)) {
            stop("must specify a list")
        }
    }
    
    # Load all possible keys for QS into \code{this_arg}
    this_arg <- c("qsori", "qsorievadj", "qsrsd", "qssadj", "qssadjevadj", "qsirr", "qsirrevadj", 
        "qssori", "qssorievadj", "qssrsd", "qsssadj", "qsssadjevadj", "qssirr", "qssirrevadj")
    
    # convert \code{this_stat} to lower case, and check to see if it matches one of the list of
    # \code{this_arg}
    is_arg <- grep(tolower(this_stat), this_arg)
    
    # If none of them match, print error message and stop
    if (length(is_arg) == 0) {
        stop(paste("Value of this_stat '", this_stat, "' not allowed.", sep = ""))
    }
    
    # filter elements of the list that are not seas objects
    seas_obj_list_update <-
      Filter(function(x) inherits(x, "seas"), seas_obj_list)

    # Generate list of QS statistics for \code{this_stat) by using \code{lapply} with \code{udg}
    qs_list <- 
       lapply(seas_obj_list_update, function(x) try(seasonal::udg(x, tolower(this_stat))))
    
    # Generate names of \code{seas_obj_list_update} that match the criteria specified
    if (less_than) {
        qs_names <- 
           names(qs_list)[matrix(unlist(qs_list), ncol = 2, byrow = T)[, 2] < p_limit]
    } else {
        qs_names <- 
           names(qs_list)[matrix(unlist(qs_list), ncol = 2, byrow = T)[, 2] > p_limit]
    }
    
    # return list of names that meet criteria, or none if no series match criteria
    if (length(qs_names) > 0) {
        return(qs_names)
    } else {
        return("none")
    }
}
