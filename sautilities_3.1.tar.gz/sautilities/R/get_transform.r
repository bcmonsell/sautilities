#' Get transformation 
#'
#' Get transformation from the \code{seas} object of a single time series
#'
#' @param m_seas \code{seas} object generated from a call of \code{seas} on a single time series
#' @return Character string with transformation used to model time series in \code{seas} run
#' @examples
#' m_air <- seasonal::seas(AirPassengers, arima.model = '(0 1 1)(0 1 1)', x11='')
#' air_trans <- get_transform(m_air)
#' @export
get_transform <- function(m_seas) {
    # Author: Brian C. Monsell (OEUS) Version 1.3 September 30, 2020
    
    # Get transformation information from UDG output
    this_trans <- seasonal::udg(m_seas, "transform")
    
    # If automatic selection used, get result of AICC test from UDG output
    if (this_trans == "Automatic selection") {
        this_trans <- seasonal::udg(m_seas, "aictrans")
    }
    
    return(this_trans)
}
