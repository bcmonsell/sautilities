#' Extract dates from outlier text
#'
#' Process name of outlier regressor to extract the dates associated with the outlier
#'
#' @param this_outlier Character string; outlier regressor
#' @param this_code Character string; code for outlier - possible values are 'ao', 'ls', 'tc', 'so', 'rp', 'tls'
#' @param this_freq integer scalar; time series frequency. Default is 12.
#' @param add_type logical scalar; determines if type of outlier is added to the output. Default is TRUE.
#' @return list of either year and month/quarter of outlier, or year and month/quarter of start and end of outlier
#' @examples
#' air_seas <- 
#'    seasonal::seas(AirPassengers, x11='', slidingspans = '', 
#'                      transform.function = 'log', arima.model = '(0 1 1)(0 1 1)', 
#'                      regression.aictest = 'td', forecast.maxlead=36, 
#'                      check.print = c( 'pacf', 'pacfplot' ))
#' this_auto_outlier <- get_auto_outlier_string(air_seas)
#' this_code         <- tolower(substr(this_auto_outlier, 1, 2))
#' this_outlier      <- proc_outlier(this_auto_outlier, this_code)
#' @export
proc_outlier <- function(this_outlier = NULL, this_code = NULL, this_freq = 12, add_type = TRUE) {
    # Author: Brian C. Monsell (OEUS) Version 1.12, 3/29/2021
    
    # check if a value is specified for \code{this_outlier}
    if (is.null(this_outlier)) {
        stop("must specify an outlier")
    }
    
    # check if a value is specified for \code{this_code}
    if (is.null(this_code)) {
        stop("must specify an outlier code")
    } else {
        this_code <- tolower(this_code)
    }
    
    # get length of outlier name, outlier code
    this_otl_length <- nchar(this_outlier)
    this_code_length <- nchar(this_code)
    
    # extract outlier year from outlier name
    this_year <- as.numeric(substr(this_outlier, this_code_length + 1, this_code_length + 4))
    
    # if outlier is a ramp or temporary level shift, extract string for the period of the start and end of
    # outlier as well as the end year
    if (this_code == "tls" | this_code == "rp") {
        this_dash <- regexpr("-", this_outlier)
        this_period_string <- substr(this_outlier, this_code_length + 6, this_dash - 1)
        this_year_2 <- as.numeric(substr(this_outlier, this_dash + 1, this_dash + 4))
        this_period_string_2 <- substr(this_outlier, this_dash + 6, this_otl_length)
    } else {
        # else extract string for the period
        this_period_string <- substr(this_outlier, this_code_length + 6, this_otl_length)
    }
    
    # Convert periods to numeric depending on the period of the time series
    if (this_freq == 4) {
        if (substr(this_period_string, 1, 1) == "q") {
            this_period <- as.numeric(substr(this_period_string, 2, this_otl_length))
        } else {
            this_period <- as.numeric(this_period_string)
        }
        if (this_code == "tls" | this_code == "rp") {
            if (substr(this_period_string, 1, 1) == "q") {
                this_period_2 <- as.numeric(substr(this_period_string_2, 2, this_otl_length))
            } else {
                this_period_2 <- as.numeric(this_period_string_2)
            }
        }
    } else {
        if (nchar(this_period_string) == 3) {
            this_period <- get_month_index(this_period_string)
        } else {
            this_period <- as.numeric(this_period_string)
        }
        if (this_code == "tls" | this_code == "rp") {
            if (nchar(this_period_string_2) == 3) {
                this_period_2 <- get_month_index(this_period_string_2)
            } else {
                this_period_2 <- as.numeric(this_period_string_2)
            }
        }
    }
    
    # return list of year, period of outliers
    if (add_type) {
        if (this_code == "tls" | this_code == "rp") {
            otl_list <- list(year = this_year, period = this_period, year2 = this_year_2, period2 = this_period_2, type = this_code)
        } else {
            otl_list <- list(year = this_year, period = this_period, type = this_code)
        }
    } else {
        if (this_code == "tls" | this_code == "rp") {
            otl_list <- list(year = this_year, period = this_period, year2 = this_year_2, period2 = this_period_2)
        } else {
            otl_list <- list(year = this_year, period = this_period)
        }
    }
    return(otl_list)
}
