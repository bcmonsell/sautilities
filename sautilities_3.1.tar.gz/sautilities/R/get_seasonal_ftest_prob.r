#' Probability of model based F-test
#'
#' Get probability for model based F-test, changing the model to remove seasonal differences and adding
#' seasonal regressors if necessary. This function is used in the overall seasonal test from Maravall (2012)
#'
#' @param this_seas \code{seas} object for a single series
#' @param this_series character string; the table used to generate the model based F-test. 
#'                    Default is "b1".
#' @return test probability generated for the model based seasonal f-test used in the seasonal
#'         testing procedure in Maravall(2012)
#' @examples 
#' m_air <- 
#'      seasonal::seas(AirPassengers, arima.model='(0 1 1)(0 1 1)', 
#'                     forecast.maxlead = 36, slidingspans = '', 
#'                     series.save = 'b1',
#'                     transform.function = 'log')
#' air_ftest_prob <- get_seasonal_ftest_prob(m_air)
#' @export
get_seasonal_ftest_prob <- function(this_seas = NULL, this_series = "b1") {
    # Author: Brian C. Monsell (OEUS) Version 3.1, 4/25/2022
    this_udg <- seasonal::udg(this_seas)
    this_index <- sautilities::get_udg_index(seasonal::udg(this_seas), "ftest$Seasonal")

    if (this_index > 0) {
        seasonal_ftest_prob <- 1.0 - sautilities::get_udg_entry(this_seas,"ftest$Seasonal")
    } else {
        seasonal_diff <- as.numeric(sautilities::get_udg_entry(this_seas,"seasonaldiff"))
        this_model <- this_udg$arimamdl
        if (seasonal_diff > 0) {
            this_new_model          <- paste0(substr(this_model,1,9), " 0 0)")
        } else {
            this_new_model          <- this_model
        }
        this_new_reg <- c(this_seas$model$regression$variables, "seasonal")
        this_seas_static <- seasonal::static(this_seas, evaluate = TRUE)
        this_seas_static_update <- 
            update(this_seas_static, x = seasonal::series(this_seas, this_series),
                   regression.variables = this_new_reg, 
                   arima.model = this_new_model)
        seasonal_ftest_prob <- 
            1.0 - sautilities::get_udg_entry(this_seas_static_update, "ftest$Seasonal")
    }
    
    return(seasonal_ftest_prob)
}