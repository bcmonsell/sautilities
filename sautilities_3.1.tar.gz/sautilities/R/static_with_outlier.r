#' add outliers to \code{seas} object 
#'
#' add arguments from the \code{outlier} spec to a \code{seas} object 
#'
#' @param this_seas_object seasonal object  
#' @param new_data time series object; updated data set from the data used to generate \code{this_seas_object} 
#' @param outlier_span character string; sets the argument \code{outlier.span}
#' @param outlier_types character string; sets the argument \code{outlier.types}
#' @return an updated static seas object with outlier arguments included.
#' @examples
#' shoes_seas <- 
#'    seasonal::seas(shoes2007, slidingspans = '', transform.function = 'log', x11 = '',
#'                    forecast.maxlead=36)
#' shoes_seas_outlier <- static_with_outlier(shoes_seas, shoes2008, outlier_types = 'all')
#' @import stats
#' @export
static_with_outlier <- function(this_seas_object = NULL, new_data = NULL, outlier_span = ",", 
                                outlier_types = "ao,ls") {
    # Author: Brian C. Monsell (OEUS) Version 2.6, 3/29/2021
    
    # check if a value is specified for \code{this_seas_object}
    if (is.null(this_seas_object)) {
        stop("must specify a seas object")
    }
    
    # check if a value is specified for \code{new_data}
    if (is.null(new_data)) {
        stop("must specify an updated data set")
    }
    
    # save static version of seas object
    static_seas_object <- seasonal::static(this_seas_object, evaluate = TRUE)
    
    # update static version of object with updated data, outlier arguments
    static_seas_object_outlier <- update(static_seas_object, x = new_data, outlier.span = outlier_span, outlier.types = outlier_types)
    
    # return static version of object
    return(static_seas_object_outlier)
}
